<meta charset="utf-8">
<title>{{ $title ?? '' }} | Konrix - Responsive Tailwind Admin Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">
<meta content="coderthemes" name="author">

<!-- App favicon -->
<link rel="shortcut icon" href="/images/favicon.ico">
