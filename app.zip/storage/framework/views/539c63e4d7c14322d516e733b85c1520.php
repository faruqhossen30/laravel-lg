
<div class="owl-carousel owl-theme slider bg-red-600">
    <div class="item flex items-center justify-between">
        <div>
            <p class=" text-lg italic">New Collections 2019</p>
            <h1 class="text-5xl italic ">Euerything is on Sale* Upto 55% off</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto sunt et excepturi mollitia, rerum
                alias ipsa .</p>
            <button>Shop Now</button>
        </div>

        <div>
            <img src="<?php echo e(asset('img/slider/product-1.png')); ?>" alt="">
        </div>
    </div>
    <div class="item flex items-center justify-between">
        <div>
            <p class=" text-lg italic">New Collections 2019</p>
            <h1 class="text-5xl italic ">Euerything is on Sale* Upto 55% off</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto sunt et excepturi mollitia, rerum
                alias ipsa .</p>
            <button>Shop Now</button>
        </div>

        <div>
            <img src="<?php echo e(asset('img/slider/product-1.png')); ?>" alt="">
        </div>
    </div>
    <div class="item flex items-center justify-between">
        <div>
            <p class=" text-lg italic">New Collections 2019</p>
            <h1 class="text-5xl italic ">Euerything is on Sale* Upto 55% off</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto sunt et excepturi mollitia, rerum
                alias ipsa .</p>
            <button>Shop Now</button>
        </div>

        <div>
            <img src="<?php echo e(asset('img/slider/product-1.png')); ?>" alt="">
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\laravel-leathergoods\resources\views/layout/slider.blade.php ENDPATH**/ ?>