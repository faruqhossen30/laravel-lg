
import GLightbox from 'glightbox';

// GLightbox Popup
var lightbox = GLightbox({
    selector: '.image-popup',
    title: false,
});

// GLightbox Popup

var lightboxDesc = GLightbox({
    selector: '.image-popup-desc',
});

// GLightbox Video Pop-up Button 
var lightboxvideo = GLightbox({
    selector: '.image-popup-video-button',
    title: false,
});

// GLightbox Video
var lightboxvideo = GLightbox({
    selector: '.image-popup-video',
    title: false,
});

// GLightbox Iframes and Inline Elements
var lightboxvideo = GLightbox({
    selector: '.image-iframe-elements',
    title: false,
});